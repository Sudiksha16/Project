# Tic-Tac-Toe-using-Django-Python :

In this project, I have worked on Django to build the Tic-Tac-Toe Game in Python Environment using Visual Studio Code.

# How to run this project :

1- Download the entire project and open it in Visual Studio Code.

2- Install python and pip from python website.

3- Install django using pip in cmd.
> pip install django

4- Run the project.
> python3 manage.py runserver

5- Now you can SignUp and send game invitation to other users. When they accept your request, you can see it in Active games and play with them. Then you can play turn by turn.
